var questions = [
  {
    "question": "Hypertext Makrup Language is also called",
    "option1": "HML",
    "option2": "CSS",
    "option3": "HTML",
    "option4": "None of the Above",
    "answer": "3"
  },
  {
    "question": "CSS is an acronym for..",
    "option1": "Case Style Sheet",
    "option2": "Cascading Style Sheet",
    "option3": "Casding Style Sheet",
    "option4": "Casett Style Sheet",
    "answer": "2"

  },
  {
    "question": "Which of the following statement is true",
    "option1": "CSS is a markup language",
    "option2": "HTML adds interactivity to web pages",
    "option3": "JavaScript is a programming language",
    "option4": "CSS is a programming language",
    "answer": "3"
  },
  {
    "question": "All of the following are true except..",
    "option1": "Inline-styling",
    "option2": "Embedded styling",
    "option3": "External styling",
    "option4": "Intra-styling",
    "answer": "4"
  },
  {
    "question": "Javascript data types include the following except",
    "option1": "String",
    "option2": "Boolean",
    "option3": "Number",
    "option4": "Alphabet",
    "answer": "4"
  },
  {
    "question": "In CSS, an ID is called using..",
    "option1": "#",
    "option2": "/",
    "option3": "@",
    "option4": "?",
    "answer": "1"
  },
  {
    "question": "HTML pages are linked using one of the following",
    "option1": "anchor/a tag",
    "option2": "image tag",
    "option3": "div tag",
    "option4": "span tag",
    "answer": "1"
  },
  {
    "question": "Which of the following is not a heading tag",
    "option1": "h4",
    "option2": "h6",
    "option3": "h2",
    "option4": "h7",
    "answer": "4"
  },
  {
    "question": "What is JavaScript?",
    "option1": "It is a markup language",
    "option2": "It is styling language",
    "option3": "It is a programming language",
    "option4": "It is also called Java",
    "answer": "3"
  },
  {
    "question": "JavaScript is also known as?",
    "option1": "EdmaScript",
    "option2": "EmaScript",
    "option3": "Escript",
    "option4": "EcmaScript",
    "answer": "4"
  },
  {
    "question": "Which of the following is true of HTML attributes?",
    "option1": "provides link to CSS files",
    "option2": "Link HTML files to JavaScript files",
    "option3": "Provides additional information about HTML elements",
    "option4": "Provides additional information about HTML and CSS",
    "answer": "3"
  }
]